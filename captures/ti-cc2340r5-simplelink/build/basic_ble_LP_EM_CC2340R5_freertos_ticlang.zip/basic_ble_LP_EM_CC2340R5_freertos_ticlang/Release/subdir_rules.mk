################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
build-33521327: ../basic_ble.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"T:/ti/sysconfig_1.20.0/sysconfig_cli.bat" -s "T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/.metadata/product.json" --script "C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang/basic_ble.syscfg" -o "syscfg" --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/ti_ble_config.h: build-33521327 ../basic_ble.syscfg
syscfg/ti_ble_config.c: build-33521327
syscfg/ti_devices_config.c: build-33521327
syscfg/ti_radio_config.c: build-33521327
syscfg/ti_radio_config.h: build-33521327
syscfg/ti_drivers_config.c: build-33521327
syscfg/ti_drivers_config.h: build-33521327
syscfg/ti_utils_build_linker.cmd.genlibs: build-33521327
syscfg/ti_utils_build_linker.cmd.genmap: build-33521327
syscfg/ti_utils_build_compiler.opt: build-33521327
syscfg/syscfg_c.rov.xs: build-33521327
syscfg/FreeRTOSConfig.h: build-33521327
syscfg/ti_freertos_config.c: build-33521327
syscfg/ti_freertos_portable_config.c: build-33521327
syscfg/: build-33521327

syscfg/%.o: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"T:/ti/ti-cgt-armllvm_3.0.0.STS/bin/tiarmclang.exe" -c @"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/config/build_components.opt" @"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/config/factory_config.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -Oz -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang" -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang/Release" -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang/app" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/controller/cc26xx/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/rom" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/common/cc26xx" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/target/_common" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/common/cc26xx/npi/stack" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/heapmgr" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/profiles/dev_info" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/profiles/simple_profile" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/npi/src" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/osal/src/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/services/src/saddr" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/services/src/sdata" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/common/nv" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/common/cc26xx" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/bleapp/profiles/health_thermometer" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/bleapp/services/health_thermometer" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/rcl" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/posix/ticlang" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/portable/GCC/ARM_CM0" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/kernel/freertos" -DICALL_NO_APP_EVENTS -DCC23X0 -DNVOCMP_NWSAMEITEM=1 -DFLASH_ONLY_BUILD -DUSE_RCL -DNVOCMP_NVPAGES=6 -DFREERTOS -DNVOCMP_POSIX_MUTEX -gdwarf-3 -ffunction-sections -MMD -MP -MF"syscfg/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang/Release/syscfg" -std=c99 $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"T:/ti/ti-cgt-armllvm_3.0.0.STS/bin/tiarmclang.exe" -c @"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/config/build_components.opt" @"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/config/factory_config.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -Oz -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang" -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang/Release" -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang/app" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/controller/cc26xx/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/rom" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/common/cc26xx" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/target/_common" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/common/cc26xx/npi/stack" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/heapmgr" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/profiles/dev_info" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/profiles/simple_profile" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/npi/src" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/osal/src/inc" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/services/src/saddr" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/services/src/sdata" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/common/nv" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/common/cc26xx" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/bleapp/profiles/health_thermometer" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/bleapp/services/health_thermometer" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/rcl" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/posix/ticlang" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/portable/GCC/ARM_CM0" -I"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/kernel/freertos" -DICALL_NO_APP_EVENTS -DCC23X0 -DNVOCMP_NWSAMEITEM=1 -DFLASH_ONLY_BUILD -DUSE_RCL -DNVOCMP_NVPAGES=6 -DFREERTOS -DNVOCMP_POSIX_MUTEX -gdwarf-3 -ffunction-sections -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/biosb/workspace_v12/basic_ble_LP_EM_CC2340R5_freertos_ticlang/Release/syscfg" -std=c99 $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


