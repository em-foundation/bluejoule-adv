# FIXED

syscfg/ti_freertos_portable_config.o: \
 syscfg/ti_freertos_portable_config.c \
 syscfg/FreeRTOSConfig.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/posix/freertos/PTLS.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/portable/GCC/ARM_CM0/port.c \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/FreeRTOS.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/projdefs.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/portable.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/deprecated_definitions.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/portable/GCC/ARM_CM0/portmacro.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/mpu_wrappers.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/task.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/list.h

syscfg/FreeRTOSConfig.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/posix/freertos/PTLS.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/portable/GCC/ARM_CM0/port.c:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/FreeRTOS.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/projdefs.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/portable.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/deprecated_definitions.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/portable/GCC/ARM_CM0/portmacro.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/mpu_wrappers.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/task.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/third_party/freertos/include/list.h:
