# FIXED

syscfg/ti_devices_config.o: syscfg/ti_devices_config.c \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/DeviceFamily.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_ccfg.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_device.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_memmap.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_platform.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_pmctl.h

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/DeviceFamily.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_ccfg.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_device.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_memmap.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_platform.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_pmctl.h:
