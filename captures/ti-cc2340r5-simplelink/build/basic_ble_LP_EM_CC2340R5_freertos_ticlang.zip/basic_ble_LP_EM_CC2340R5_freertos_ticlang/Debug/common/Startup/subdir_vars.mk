################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/stack/ble_user_config_stack.c \
../common/Startup/osal_icall_ble.c \
T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/rom/agama_r1/rom_init.c 

C_DEPS += \
./common/Startup/ble_user_config_stack.d \
./common/Startup/osal_icall_ble.d \
./common/Startup/rom_init.d 

OBJS += \
./common/Startup/ble_user_config_stack.o \
./common/Startup/osal_icall_ble.o \
./common/Startup/rom_init.o 

OBJS__QUOTED += \
"common\Startup\ble_user_config_stack.o" \
"common\Startup\osal_icall_ble.o" \
"common\Startup\rom_init.o" 

C_DEPS__QUOTED += \
"common\Startup\ble_user_config_stack.d" \
"common\Startup\osal_icall_ble.d" \
"common\Startup\rom_init.d" 

C_SRCS__QUOTED += \
"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/stack/ble_user_config_stack.c" \
"../common/Startup/osal_icall_ble.c" \
"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/rom/agama_r1/rom_init.c" 


