################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_POSIX.c \
T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_cc23x0.c \
T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_user_config.c 

C_DEPS += \
./common/iCall/icall_POSIX.d \
./common/iCall/icall_cc23x0.d \
./common/iCall/icall_user_config.d 

OBJS += \
./common/iCall/icall_POSIX.o \
./common/iCall/icall_cc23x0.o \
./common/iCall/icall_user_config.o 

OBJS__QUOTED += \
"common\iCall\icall_POSIX.o" \
"common\iCall\icall_cc23x0.o" \
"common\iCall\icall_user_config.o" 

C_DEPS__QUOTED += \
"common\iCall\icall_POSIX.d" \
"common\iCall\icall_cc23x0.d" \
"common\iCall\icall_user_config.d" 

C_SRCS__QUOTED += \
"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_POSIX.c" \
"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_cc23x0.c" \
"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_user_config.c" 


