# FIXED

common/iCall/icall_cc23x0.o: \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_cc23x0.c \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_platform.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/inc/icall.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/inc/hal_assert.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/target/_common/hal_types.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/inc/hal_defs.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/inc/icall_cc23x0_defs.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/Power.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/utils/List.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/DeviceFamily.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/power/PowerCC23X0.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/dpl/HwiP.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/dpl/ClockP.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_pmctl.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_clkctl.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_lrfddbell.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_memmap.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_types.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/driverlib/pmctl.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_types.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_memmap.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_pmctl.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/cmsis/cc23x0r5.h \
 T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/cmsis/core/core_cm0plus.h

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/icall_platform.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/inc/icall.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/inc/hal_assert.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/target/_common/hal_types.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/hal/src/inc/hal_defs.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/ble5stack_flash/icall/src/inc/icall_cc23x0_defs.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/Power.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/utils/List.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/DeviceFamily.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/power/PowerCC23X0.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/dpl/HwiP.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/drivers/dpl/ClockP.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_pmctl.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_clkctl.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_lrfddbell.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_memmap.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_types.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/driverlib/pmctl.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_types.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_memmap.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/inc/hw_pmctl.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/cmsis/cc23x0r5.h:

T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/devices/cc23x0r5/cmsis/core/core_cm0plus.h:
