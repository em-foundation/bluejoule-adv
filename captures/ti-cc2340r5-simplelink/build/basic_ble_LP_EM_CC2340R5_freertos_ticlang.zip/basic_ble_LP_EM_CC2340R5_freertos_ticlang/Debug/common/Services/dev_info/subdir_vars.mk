################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/bleapp/services/dev_info/dev_info_service.c 

C_DEPS += \
./common/Services/dev_info/dev_info_service.d 

OBJS += \
./common/Services/dev_info/dev_info_service.o 

OBJS__QUOTED += \
"common\Services\dev_info\dev_info_service.o" 

C_DEPS__QUOTED += \
"common\Services\dev_info\dev_info_service.d" 

C_SRCS__QUOTED += \
"T:/ti/simplelink_lowpower_f3_sdk_8_10_00_55/source/ti/bleapp/services/dev_info/dev_info_service.c" 


