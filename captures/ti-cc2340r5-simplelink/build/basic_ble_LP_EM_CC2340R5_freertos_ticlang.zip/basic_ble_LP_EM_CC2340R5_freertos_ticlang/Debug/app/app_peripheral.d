# FIXED

app/app_peripheral.o: ../app/app_peripheral.c
