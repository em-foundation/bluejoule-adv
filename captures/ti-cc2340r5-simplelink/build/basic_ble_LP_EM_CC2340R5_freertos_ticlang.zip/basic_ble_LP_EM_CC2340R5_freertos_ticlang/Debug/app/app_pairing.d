# FIXED

app/app_pairing.o: ../app/app_pairing.c
